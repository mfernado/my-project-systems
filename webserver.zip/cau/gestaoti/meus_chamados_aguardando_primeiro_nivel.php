<?php
/*
Copyright 2011 da EMBRATUR
�Este arquivo � parte do programa CAU - Central de Atendimento ao Usu�rio
�O CAU � um software livre; voc� pode redistribu�-lo e/ou modific�-lo dentro dos termos da Licen�a P�blica Geral GNU como publicada pela 
 Funda��o do Software Livre (FSF); na vers�o 2 da Licen�a.
�Este programa � distribu�do na esperan�a que possa ser� �til, mas SEM NENHUMA GARANTIA; sem uma garantia impl�cita de ADEQUA��O a qualquer� 
 MERCADO ou APLICA��O EM PARTICULAR. Veja a Licen�a P�blica Geral GNU/GPL em portugu�s para maiores detalhes.
�Observe no diret�rio gestaoti/install/ a c�pia da Licen�a P�blica Geral GNU, sob o t�tulo "licensa_uso.htm". 
 Se preferir acesse o Portal do Software P�blico Brasileiro no endere�o www.softwarepublico.gov.br ou escreva para a Funda��o do Software 
 Livre(FSF) Inc., 51 Franklin St, Fifth Floor, Boston, MA� 02110-1301, USA
*/
require 'include/PHP/class/class.pagina.php';
$pagina = new Pagina();
?>
<link href="<?=$pagina->vPathPadrao?>include/CSS/visoes.css" rel="stylesheet" type="text/css" />
<table class="width100" cellspacing="1">
<tr>
		<td class="form-title" colspan="2">
		<a class="subtle" href="view_all_set.php?type=1&amp;temporary=y&amp;handler_id=[none]&amp;hide_status=90">Unassigned</a> [<a class="subtle" href="view_all_set.php?type=1&amp;temporary=y&amp;handler_id=[none]&amp;hide_status=90" target="_blank">^</a>]		(1 - 10 / 307)	</td>
</tr>


<tr bgcolor="#ffa0a0">
		<td class="center" valign="top" width ="0" nowrap>
		<span class="small">
		<a href="view.php?id=7184" title="[new] efre">0007184</a><br />&nbsp;		</span>
	</td>

		<td class="left" valign="top" width="100%">
		<span class="small">
		efre		<br />
		[Demo] GUI - <b>2009-11-10 12:09</b>		</span>
	</td>
</tr>

<tr bgcolor="#ffa0a0">
		<td class="center" valign="top" width ="0" nowrap>
		<span class="small">
		<a href="view.php?id=7177" title="[new] Bild nicht geladen">0007177</a><br />&nbsp;		</span>
	</td>

		<td class="left" valign="top" width="100%">
		<span class="small">
		Bild nicht geladen		<br />
		[Demo] Website - 2009-11-10 06:32		</span>
	</td>
</tr>

<tr bgcolor="#ffa0a0">
		<td class="center" valign="top" width ="0" nowrap>
		<span class="small">
		<a href="view.php?id=7172" title="[new] kkkkkkk">0007172</a><br /><img src="http://www.mantisbt.org/demo/images/priority_3.gif" alt="" title="immediate" />		</span>
	</td>

		<td class="left" valign="top" width="100%">
		<span class="small">
		kkkkkkk		<br />
		[Demo] GUI - 2009-11-10 00:19		</span>
	</td>
</tr>

<tr bgcolor="#ffa0a0">
		<td class="center" valign="top" width ="0" nowrap>
		<span class="small">
		<a href="view.php?id=7112" title="[new] this is the test how it looks in mantis">0007112</a><br />&nbsp;		</span>
	</td>

		<td class="left" valign="top" width="100%">
		<span class="small">
		this is the test how it looks in mantis		<br />
		[Demo] GUI - 2009-11-02 12:16		</span>
	</td>
</tr>

<tr bgcolor="#ffa0a0">
		<td class="center" valign="top" width ="0" nowrap>
		<span class="small">
		<a href="view.php?id=7113" title="[new] n/a">0007113</a><br />&nbsp;		</span>
	</td>

		<td class="left" valign="top" width="100%">
		<span class="small">
		n/a		<br />
		[Demo] Website - 2009-11-01 23:44		</span>
	</td>
</tr>

<tr bgcolor="#c8c8ff">
		<td class="center" valign="top" width ="0" nowrap>
		<span class="small">
		<a href="view.php?id=7111" title="[assigned] probleme mit test">0007111</a><br />&nbsp;		</span>
	</td>

		<td class="left" valign="top" width="100%">
		<span class="small">
		probleme mit test		<br />
		[Demo] GUI - 2009-11-01 15:10		</span>
	</td>
</tr>

<tr bgcolor="#ffa0a0">
		<td class="center" valign="top" width ="0" nowrap>
		<span class="small">
		<a href="view.php?id=7108" title="[new] teste de software">0007108</a><br />&nbsp;		</span>
	</td>

		<td class="left" valign="top" width="100%">
		<span class="small">
		teste de software		<br />
		[Demo] GUI - 2009-10-30 10:45		</span>
	</td>
</tr>

<tr bgcolor="#ffa0a0">
		<td class="center" valign="top" width ="0" nowrap>
		<span class="small">
		<a href="view.php?id=7107" title="[new] Algo sin importancia">0007107</a><br /><img src="http://www.mantisbt.org/demo/images/priority_low_1.gif" alt="" title="low" />		</span>
	</td>

		<td class="left" valign="top" width="100%">
		<span class="small">
		Algo sin importancia		<br />
		[Demo] Website - 2009-10-30 09:23		</span>
	</td>
</tr>

<tr bgcolor="#ff50a8">
		<td class="center" valign="top" width ="0" nowrap>
		<span class="small">
		<a href="view.php?id=6518" title="[feedback] problem with utf-8 (rusian text = ??????? ?????)">0006518</a><br />&nbsp;		</span>
	</td>

		<td class="left" valign="top" width="100%">
		<span class="small">
		problem with utf-8 (rusian text = ??????? ?????)		<br />
		[Demo] GUI - 2009-10-30 07:38		</span>
	</td>
</tr>

<tr bgcolor="#ffa0a0">
		<td class="center" valign="top" width ="0" nowrap>
		<span class="small">
		<a href="view.php?id=7102" title="[new] &lt;yxc">0007102</a><br />&nbsp;		</span>
	</td>

		<td class="left" valign="top" width="100%">
		<span class="small">
		&lt;yxc		<br />
		[Demo] Other - 2009-10-30 05:24		</span>
	</td>
</tr>

</table>