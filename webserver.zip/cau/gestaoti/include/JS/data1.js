var isHorizontal=1;

var pressedItem = "S";

var blankImage="imagens/blank.gif";
var fontStyle="bold 11pt Verdana";
var fontColor=["#0072B6","#605c5b"];
var fontDecoration=["none","none"];

var itemBackColor=["#BBCCD6","#ffffff"];
var itemBorderWidth=0;
var itemAlign="left";
var itemBorderColor=["#6655ff","#665500"];
var itemBorderStyle=["solid","solid"];
var itemBackImage=["",""];

var menuBackImage="";
var menuBackColor="#BBCCD6";
var menuBorderColor="#000000";
var menuBorderStyle="solid";
var menuBorderWidth=0;
var transparency=90;
var transition=24;
var transDuration=500;
var shadowColor="#BBCCD6";
var shadowLen=4;
var menuWidth="";

var itemCursor="hand";
//var itemTarget="_blank";
var itemTarget="";
var statusString="text";
var subMenuAlign = "left";
var iconTopWidth  = 16;
var iconTopHeight = 16;
var iconWidth=16;
var iconHeight=16;
var arrowImageMain=["imagens/arrow_d.gif","imagens/arrow_d2.gif"];
var arrowImageSub=["imagens/arrow_r.gif","imagens/arrow_r2.gif"];
var arrowWidth=7;
var arrowHeight=7;
var itemSpacing=1;
var itemPadding=2;

var separatorImage="imagens/separ1.gif";
var separatorWidth="100%";
var separatorHeight="5";
var separatorAlignment="center";

var separatorVImage="imagens/separv1.gif";
var separatorVWidth="5";
var separatorVHeight="16";

var moveCursor = "move";
var movable = 0;
var absolutePos = 0;
var posX = 20;
var posY = 100;

var floatable=1;
var floatIterations=5;