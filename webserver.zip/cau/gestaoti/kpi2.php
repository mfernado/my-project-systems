<?php
/*
Copyright 2011 da EMBRATUR
�Este arquivo � parte do programa CAU - Central de Atendimento ao Usu�rio
�O CAU � um software livre; voc� pode redistribu�-lo e/ou modific�-lo dentro dos termos da Licen�a P�blica Geral GNU como publicada pela 
 Funda��o do Software Livre (FSF); na vers�o 2 da Licen�a.
�Este programa � distribu�do na esperan�a que possa ser� �til, mas SEM NENHUMA GARANTIA; sem uma garantia impl�cita de ADEQUA��O a qualquer� 
 MERCADO ou APLICA��O EM PARTICULAR. Veja a Licen�a P�blica Geral GNU/GPL em portugu�s para maiores detalhes.
�Observe no diret�rio gestaoti/install/ a c�pia da Licen�a P�blica Geral GNU, sob o t�tulo "licensa_uso.htm". 
 Se preferir acesse o Portal do Software P�blico Brasileiro no endere�o www.softwarepublico.gov.br ou escreva para a Funda��o do Software 
 Livre(FSF) Inc., 51 Franklin St, Fifth Floor, Boston, MA� 02110-1301, USA
*/
require 'include/PHP/class/class.pagina.php';
require 'include/PHP/class/class.kpi2.php';
$pagina = new Pagina();
$kpi = new kpi2();

// =================================================================================
// Passagem de par�metros e sele��o do gr�fico
// =================================================================================
if($vGrafico == "KpiChamadosPorSituacao"){
	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->KpiChamadosPorSituacao();
}elseif($vGrafico == "KpiChamadosPorPrioridade"){
	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->KpiChamadosPorPrioridade();
}elseif($vGrafico == "KpiChamadosPorLotacao"){
	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->KpiChamadosPorLotacao();
}elseif($vGrafico == "KpiChamadosPorSistemaInformacao"){
	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->KpiChamadosPorSistemaInformacao();
}elseif($vGrafico == "KpiChamadosPorSLA"){
	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->KpiChamadosPorSLA();
}elseif($vGrafico == "KpiChamadosPorDependencia"){
	$kpi->KpiChamadosPorDependencia();
}elseif($vGrafico == "KpiChamadosPorEquipe"){
	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->KpiChamadosPorEquipe();
}elseif($vGrafico == "KpiChamadosPorProfissional"){
	$kpi->KpiChamadosPorProfissional();
}elseif($vGrafico == "KpiHorasPorProfissional"){
	$kpi->KpiHorasPorProfissional();
}elseif($vGrafico == "KpiHorasPorEquipe"){
	$kpi->KpiHorasPorEquipe();
}elseif($vGrafico == "KpiChamadosPorAvaliacao"){
	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->KpiChamadosPorAvaliacao();
}elseif($vGrafico == "KpiChamadosPorAvaliacao_Satisfacao_Conhecimento"){
	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->KpiChamadosPorAvaliacao_Satisfacao_Conhecimento();
}elseif($vGrafico == "KpiChamadosPorAvaliacao_Satisfacao_Postura"){
	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->KpiChamadosPorAvaliacao_Satisfacao_Postura();
}elseif($vGrafico == "KpiChamadosPorAvaliacao_Satisfacao_Tempo_Espera"){
	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->KpiChamadosPorAvaliacao_Satisfacao_Tempo_Espera();
}elseif($vGrafico == "KpiChamadosPorAvaliacao_Satisfacao_Tempo_Solucao"){
	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->KpiChamadosPorAvaliacao_Satisfacao_Tempo_Solucao();
}elseif($vGrafico == "KpiChamadosPorAtividade"){
	$kpi->KpiChamadosPorAtividade();
}elseif($vGrafico == "KpiChamadosPorSubtipo"){
	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->SEQ_TIPO_CHAMADO = $v_SEQ_TIPO_CHAMADO;
	$kpi->KpiChamadosPorSubtipo();
}elseif($vGrafico == "KpiChamadosPorTipo"){
	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->KpiChamadosPorTipo();
}elseif($vGrafico == "KpiQtdProfissionaisPorEquipe"){
	$kpi->KpiQtdProfissionaisPorEquipe();
}elseif($vGrafico == "KpiValorProfissionaisPorEquipe"){
	$kpi->KpiValorProfissionaisPorEquipe();
}elseif($vGrafico == "KpiQtdSistemasPorLinguagem"){
	$kpi->KpiQtdSistemasPorLinguagem();
}elseif($vGrafico == "KpiQtdSistemasPorBancoDeDados"){
	$kpi->KpiQtdSistemasPorBancoDeDados();
}elseif($vGrafico == "KpiQtdProfissionaisPorAreaAtuacao"){
	$kpi->KpiQtdProfissionaisPorAreaAtuacao();
}elseif($vGrafico == "KpiPorcentagemChamadosEncerradosNoPrazo"){
	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->KpiPorcentagemChamadosEncerradosNoPrazo();
}elseif($vGrafico == "KpiPorcentagemChamadosEncerradosNoPrazoIncidente"){
	$kpi->arFaixaOdometro = array();
	$kpi->arFaixaOdometro[0][0] = "0";
	$kpi->arFaixaOdometro[0][1] = "90";
	$kpi->arFaixaOdometro[0][2] = "red";

	$kpi->arFaixaOdometro[1][0] = "90";
	$kpi->arFaixaOdometro[1][1] = "100";
	$kpi->arFaixaOdometro[1][2] = "green";

	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->KpiPorcentagemChamadosEncerradosNoPrazoIncidente();
}elseif($vGrafico == "KpiPorcentagemChamadosEncerradosNoPrazoSolicitacao"){
	$kpi->arFaixaOdometro = array();
	$kpi->arFaixaOdometro[0][0] = "0";
	$kpi->arFaixaOdometro[0][1] = "70";
	$kpi->arFaixaOdometro[0][2] = "red";

	$kpi->arFaixaOdometro[1][0] = "70";
	$kpi->arFaixaOdometro[1][1] = "80";
	$kpi->arFaixaOdometro[1][2] = "yellow";

	$kpi->arFaixaOdometro[2][0] = "80";
	$kpi->arFaixaOdometro[2][1] = "100";
	$kpi->arFaixaOdometro[2][2] = "green";

	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->KpiPorcentagemChamadosEncerradosNoPrazoSolicitacao();
}elseif($vGrafico == "KpiPorcentagemChamadosEmAndamentoNoPrazo"){
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->KpiPorcentagemChamadosEmAndamentoNoPrazo();
}elseif($vGrafico == "KpiQtdChamadosPorSLAPorMes"){
	$kpi->KpiQtdChamadosPorSLAPorMes();
}elseif($vGrafico == "KpiQtdAvaliacoesPorMes"){
	$kpi->KpiQtdAvaliacoesPorMes();
}elseif($vGrafico == "KpiChamadosPorTipoOcorrencia"){
	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->SEQ_EQUIPE_TI = $v_SEQ_EQUIPE_TI;
	$kpi->KpiChamadosPorTipoOcorrencia();
}elseif($vGrafico == "KpiChamadosPorSLANivel1"){
	$kpi->arFaixaOdometro = array();
	$kpi->arFaixaOdometro[0][0] = "0";
	$kpi->arFaixaOdometro[0][1] = "40";
	$kpi->arFaixaOdometro[0][2] = "red";

	$kpi->arFaixaOdometro[1][0] = "40";
	$kpi->arFaixaOdometro[1][1] = "50";
	$kpi->arFaixaOdometro[1][2] = "yellow";

	$kpi->arFaixaOdometro[2][0] = "50";
	$kpi->arFaixaOdometro[2][1] = "100";
	$kpi->arFaixaOdometro[2][2] = "green";

	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->KpiChamadosPorSLANivel1();
}elseif($vGrafico == "TempoMedioNivel1"){
	$kpi->DTH_INICIO = $v_DTH_INICIO;
	$kpi->DTH_FIM = $v_DTH_FIM;
	$kpi->TempoMedioNivel1();
}

// =================================================================================
// Montar o gr�fico
// =================================================================================
if($vGrafico != ""){
	// Montar o gr�fico
	if($vTipoGrafico == "L"){
		$kpi->GraficoLinhaSimples($kpi->dados, $kpi->label);
	}elseif($vTipoGrafico == "B"){
		$kpi->GraficoBarrasSimples($kpi->dados, $kpi->label);
	}elseif($vTipoGrafico == "P"){
		$kpi->GraficoPizzaSimples($kpi->dados, $kpi->label);
	}elseif($vTipoGrafico == "O"){
		$kpi->GraficoOdometro($kpi->valorOdometro);
	}
}
?>
